# OUTDOOR LABO — WordPress → Hugo 移行セット

リポジトリ(`config/_default/`・`themes/`・`static/`・`content/posts/`)にそのまま重ねる構成です。

## 手順
```bash
# 0) このセットをリポジトリ直下に展開(同名ファイルは差分を見ながら統合)
#    既存の config/_default/hugo.toml がある場合は、足りない項目だけ取り込む

# 1) ロゴ画像を static/images/ に置く (ol-header.png / ol.png / favicon.png)

# 2) 記事を取り込む(ネット接続のあるPCで)。まず10件だけ試す
python3 tools/wp2hugo.py --site https://outdoorlabo.a-ce.com --out . --limit 10
hugo server            # 表示を確認

# 3) 問題なければ全件(画像も static/wp-content/uploads/ に保存。時間がかかります)
python3 tools/wp2hugo.py --site https://outdoorlabo.a-ce.com --out .

# 4) テスト用のサンプル記事があれば content/posts/ から削除してから
git add -A && git commit -m "WordPressから記事を移行" && git push
```
REST API が使えない場合は、管理画面「ツール > エクスポート」で出した XML を
`--wxr export.xml` で渡してください(画像は同様にダウンロードされます)。

## 変換の中身
- 記事 → `content/posts/<slug>.md`。URL は WordPress と同じ `/2026/05/11/slug/`
- カテゴリ・タグ → スラッグをキーにし、表示名は `content/category/<slug>/_index.md` に保存
  (子カテゴリの記事には親カテゴリも付与 → 親の一覧にも子の記事が出る)
- 画像 → WordPress と同じパス `/wp-content/uploads/...` のまま `static/` に保存(画像URLが変わらない)
- 本文HTMLはそのまま保持。h2〜h4 だけ Markdown 見出しに変換(目次を効かせるため)
- 内部リンクは相対化し、階層カテゴリURL `/category/a/b/` は `/category/b/` に変換
- 固定ページ(Contact など)→ `content/<slug>.md`。`site-map` は Hugo 側の自動ページ(`content/site-map.md`)を使用

## 取り込み後に確認したい点
- 実行終了時に表示される「記事内で使われているCSSクラス」と「ショートコード風の文字列が残っている記事」
  (Cocoon のボックス・吹き出し・`[toc]` など。必要なものは `style.css` に追記)
- 画像のダウンロード失敗は `wp2hugo-failed.txt` に出力
- Contact ページのフォームは WordPress プラグインなので、Formspree などの外部フォームへ差し替えが必要
- 旧URL `/category/親/子/` から新URL `/category/子/` へのリダイレクトが必要なら別途設定

## その他
- ブログカード: `{{< blogcard url="…" title="…" desc="…" image="/images/x.jpg" >}}`
  (WordPress から取り込んだ Cocoon のブログカードHTMLもそのまま表示される)
- 配色・幅: `themes/outdoorlabo/static/css/style.css` 冒頭の変数
- Instagram グリッド: `data/instagram.yaml`
